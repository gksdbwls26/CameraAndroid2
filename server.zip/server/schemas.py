# schemas.py
from pydantic import BaseModel
from typing import List, Optional

class Joint(BaseModel):
    x: float
    y: float
    z: float
    visibility: Optional[float] = None

class SkeletonData(BaseModel):
    joints: List[Joint]