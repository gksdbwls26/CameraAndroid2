# main.py
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from typing import List
import logging
import numpy as np
import os
from datetime import datetime
import winsound # DEBUG

# 모듈 임포트
import config
from schemas import SkeletonData
from analyzer import load_models, analyze_fall_sequence, generate_llm_prompt_json, call_google_api, FallDetectionResult, process_and_analyze

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("uvicorn.error")

app = FastAPI()

# CORS 설정
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 전역 변수
models = {"gru": None, "gcn": None, "device": None, "skip_count": 0, "is_frozen": False}


@app.on_event("startup")
async def startup_event():
    """
    서버 시작 시 실행되는 함수.
    딥러닝 모델을 로드하여 전역 변수 models에 저장합니다.
    """
    global models  # 전역 변수 수정 권한 획득

    logger.info("🚀 서버 시작: 딥러닝 모델 로드를 시작합니다...")
    try:
        # analyzer.py의 load_models 함수 호출
        # config.py에 정의된 경로 사용
        gru_model, gcn_model, device = load_models(
            gru_path=config.GRU_PATH,
            gcn_path=config.GCN_PATH,
            device='auto'
        )

        # 로드된 객체들을 전역 딕셔너리에 저장
        models["gru"] = gru_model
        models["gcn"] = gcn_model
        models["device"] = device

        logger.info(f"✅ 모든 모델 로드 완료! (Device: {device})")
        logger.info(f"   - GRU Path: {config.GRU_PATH}")
        logger.info(f"   - GCN Path: {config.GCN_PATH}")



    except FileNotFoundError as e:
        logger.error(f"❌ 모델 파일을 찾을 수 없습니다: {e}")
        logger.error("   config.py의 경로 설정을 확인해주세요.")
        # 모델 파일이 없으면 서버 기능이 마비되므로 로그를 강력하게 남김

    except Exception as e:
        logger.error(f"❌ 모델 로드 중 치명적인 오류 발생: {e}", exc_info=True)


@app.get("/")
def read_root():
    return {"Status": "Running", "Models_Loaded": models["gru"] is not None}


@app.post("/pose")
async def receive_pose_data(data_window: List[SkeletonData]):
    if models["gru"] is None:
        return {"error": "Models not loaded"}, 503

    if models["is_frozen"]:
        # logger.info("🔒 디버그 모드: 데이터 수신 중단 상태입니다.")
        return {"status": "frozen", "message": "Fall detected! Server is frozen for debugging."}

    if models["skip_count"] < 5:
        models["skip_count"] += 1
        current = models["skip_count"]
        logger.warning(f"⏳ 초기 데이터 안정화 중... 스킵됨 ({current}/5)")

        # 분석 로직을 타지 않고 바로 종료
        return {
            "status": "skipped",
            "message": f"Server warming up... skipped request {current}"
        }

    try:
        if models["gru"] is None or models["gcn"] is None:
            logger.error("⛔ 모델이 로드되지 않아 요청을 처리할 수 없습니다.")
            return {"error": "Server is not ready. Models not loaded."}, 503

        try:
            # 2. 데이터 파싱 및 차원 확인
            T = len(data_window)
            # 첫 프레임이 있으면 관절 수를 가져오고, 없으면 0
            V = len(data_window[0].joints) if T > 0 else 0
            C = 4  # (x, y, z, visibility)

            if T == 0 or V == 0:
                return {"error": "Received empty data window."}, 400

            # 3. Numpy 배열 변환 (T, V, C)
            # 메모리 효율을 위해 float32 사용
            sequence_array = np.zeros((T, V, C), dtype=np.float32)

            for t, frame in enumerate(data_window):
                for v, joint in enumerate(frame.joints):
                    sequence_array[t, v, 0] = joint.x
                    sequence_array[t, v, 1] = joint.y
                    sequence_array[t, v, 2] = joint.z
                    # visibility가 None이면 0.0으로 처리
                    sequence_array[t, v, 3] = joint.visibility if joint.visibility is not None else 0.0

            # 4. 중앙점 이동과 정규화
            IDX_L_SHOULDER, IDX_R_SHOULDER = 1, 2
            IDX_L_HIP, IDX_R_HIP = 5, 6
            if V > max(IDX_L_HIP, IDX_R_HIP):
                # 1. 힙 중앙점(Hip Center) 계산
                # shape: (T, 3) -> 각 프레임별 (x, y, z)
                left_hip = sequence_array[:, IDX_L_HIP, :3]
                right_hip = sequence_array[:, IDX_R_HIP, :3]
                hip_center = (left_hip + right_hip) / 2.0

                # 2. 중앙점 이동 (Translation)
                # 모든 관절 좌표에서 힙 중앙점 좌표를 뺌
                # Broadcasting: (T, V, 3) - (T, 1, 3)
                sequence_array[:, :, :3] -= hip_center[:, None, :]

                # 3. 어깨 중앙점(Shoulder Center) 계산 (이미 0,0,0 기준이 됨)
                left_shoulder = sequence_array[:, IDX_L_SHOULDER, :3]
                right_shoulder = sequence_array[:, IDX_R_SHOULDER, :3]
                shoulder_center = (left_shoulder + right_shoulder) / 2.0

                # 4. 앵커 길이(Anchor Length) 계산 (Scale Factor)
                # 힙(0,0,0)에서 어깨 중앙점까지의 유클리드 거리
                # axis=1은 x,y,z 차원을 의미
                anchor_length = np.linalg.norm(shoulder_center, axis=1)  # 결과 shape: (T,)

                # 0 나누기 방지 (epsilon 적용)
                anchor_length = np.maximum(anchor_length, 1e-6)

                # 5. 정규화 (Scaling)
                # 모든 좌표를 앵커 길이로 나눔
                # Broadcasting: (T, V, 3) / (T, 1, 1)
                sequence_array[:, :, :3] /= anchor_length[:, None, None]

                logger.info("✅ 데이터 정규화 완료 (Hip Center & Anchor Scale)")

            else:
                logger.warning(f"⚠️ 관절 수({V})가 부족하여 정규화를 건너뜁니다.")

            # 5. 전처리: EMA (Exponential Moving Average) 스무딩
            # config.py에 EMA_ALPHA가 정의되어 있다고 가정 (없으면 0.2 사용)
            alpha = getattr(config, 'EMA_ALPHA', 0.2)
            smoothed_sequence = np.copy(sequence_array)

            # t=1부터 이전 프레임 값을 반영하여 스무딩
            for t in range(1, T):
                prev_smoothed = smoothed_sequence[t - 1]
                current_raw = sequence_array[t]
                smoothed_sequence[t] = alpha * current_raw + (1 - alpha) * prev_smoothed

            sequence_array = smoothed_sequence  # 원본을 스무딩된 데이터로 교체

            # 6. 전처리: 낮은 신뢰도(Visibility) 보정
            threshold = getattr(config, 'SMOOTHING_THRESHOLD', 0.5)

            for t in range(1, T):
                # 이전 프레임의 신뢰도가 낮았던 관절 찾기
                low_vis_mask = sequence_array[t - 1, :, 3] < threshold
                # 신뢰도가 낮으면 좌표 변화를 무시하고 이전 값 유지
                sequence_array[t, low_vis_mask, :3] = sequence_array[t - 1, low_vis_mask, :3]

            # 7. 디버깅용 데이터 저장 DEBUG
            debug_dir = "debug_sequences"
            os.makedirs(debug_dir, exist_ok=True)
            timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S_%f")

            # .npy 파일 저장
            output_path = os.path.join(debug_dir, f"live_seq_{timestamp_str}.npy")
            np.save(output_path, sequence_array)

            # 데이터 통계 로그
            xyz_flat = sequence_array[:, :, :3].flatten()
            logger.info(f"💾 데이터 수신: T={T}, V={V} | Min={np.min(xyz_flat):.2f}, Max={np.max(xyz_flat):.2f}")

            # 8. 분석 모듈 호출 (analyzer.py)
            analysis_output = process_and_analyze(
                sequence_array,
                models["gru"],
                models["gcn"],
                models["device"]
            )

            # DEBUG: 낙상 발생시 로그 종료
            detection_result = analysis_output['detection_result']

            if detection_result.is_fall:
                models["is_frozen"] = True  # 🛑 서버 동결!
                try:
                    # 영상 소리를 뚫고 들리도록 고음(2000Hz) 사용
                    winsound.Beep(2000, 300)  # 짧게
                    winsound.Beep(2000, 300)  # 짧게
                    winsound.Beep(2000, 1000)  # 길게 (1초)
                except Exception as e:
                    logger.error(f"소리 재생 실패: {e}")

                logger.error("=" * 60)
                logger.error("🛑 [DEBUG] 낙상 감지됨! 들어오는 모든 데이터를 차단합니다.")
                logger.error(f"   - 확신도: {detection_result.fall_confidence * 100:.2f}%")
                logger.error(f"   - 부위: {detection_result.impact_location}")
                logger.error("   (서버를 재시작해야 다시 데이터를 받을 수 있습니다)")
                logger.error("=" * 60)

            # 8. 결과 반환
            # FallDetectionResult 객체는 직렬화가 안 되므로 .to_dict() 호출
            return {
                "status": "success",
                "detection": analysis_output['detection_result'].to_dict(),
                "llm_analysis": analysis_output['llm_analysis']
            }

        except Exception as e:
            logger.error(f"❌ [/pose] 처리 중 오류 발생: {e}", exc_info=True)
            return {"error": "Failed to process data", "details": str(e)}, 500

    except Exception as e:
        logger.error(f"에러 발생: {e}")
        return {"error": str(e)}, 500


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, log_level="info", access_log=False)