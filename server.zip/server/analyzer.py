# analyzer.py
import torch
import numpy as np
import logging
import google.generativeai as genai
from datetime import datetime
from dl_models import GRUFallDetection, MultiClassSTGCN  # 분리한 모델 임포트
import config
from openai import OpenAI

logger = logging.getLogger("uvicorn.error")


class FallDetectionResult:
    """결과 저장 클래스 (기존 코드 유지)"""

    def __init__(self):
        self.timestamp = datetime.now()
        self.is_fall = False
        self.fall_confidence = 0.0
        self.fall_probabilities = [0.0, 0.0]
        self.impact_location = None
        self.impact_confidence = 0.0
        self.impact_probabilities = {}
        self.person_info = {}

    def set_fall_detection(self, is_fall, confidence, probabilities):
        self.is_fall = is_fall
        self.fall_confidence = confidence
        self.fall_probabilities = probabilities

    def set_impact_classification(self, impact_location, confidence, probabilities):
        self.impact_location = impact_location
        self.impact_confidence = confidence
        self.impact_probabilities = probabilities

    def to_dict(self):
        return {
            'timestamp': self.timestamp.isoformat(),
            'is_fall': self.is_fall,
            'fall_confidence': float(self.fall_confidence),
            'impact_location': self.impact_location,
            'impact_confidence': float(self.impact_confidence) if self.impact_confidence else None,
            'person_info': self.person_info
        }

# --- 모델 로드 관련 함수들 ---
from dl_models import GRUFallDetection, MultiClassSTGCN

logger = logging.getLogger("uvicorn.error")


def get_adjacency_matrix(num_joints=15):
    """ST-GCN용 인접 행렬 생성 헬퍼 함수"""
    connections = [
        (0, 1), (0, 2), (1, 2),
        (1, 3), (2, 4),
        (1, 5), (2, 6), (5, 6),
        (5, 7), (7, 9), (9, 12), (9, 13), (12, 13),
        (6, 8), (8, 10), (10, 11), (10, 14), (11, 14),
    ]

    A = np.eye(num_joints)
    for i, j in connections:
        if i < num_joints and j < num_joints:
            A[i, j] = 1
            A[j, i] = 1

    D = np.sum(A, axis=1)
    D_inv_sqrt = np.power(D, -0.5)
    D_inv_sqrt[np.isinf(D_inv_sqrt)] = 0.
    D_mat = np.diag(D_inv_sqrt)
    A_normalized = D_mat @ A @ D_mat

    return torch.FloatTensor(A_normalized)


def load_models(gru_path, gcn_path, device='auto'):
    if device == 'auto':
        device = 'cuda' if torch.cuda.is_available() else 'cpu'

    device_obj = torch.device(device)
    print(f"디바이스 설정: {device}")

    # 1. GRU 로드
    gru_model = GRUFallDetection(
        input_dim=60,
        hidden_dim=128,
        num_layers=2,
        dropout=0.5,
        bidirectional=True
    )
    gru_model.load_state_dict(torch.load(gru_path, map_location=device_obj))
    gru_model.to(device_obj)
    gru_model.eval()

    # 2. GCN 로드 (수정된 부분)
    # 2-1. 인접 행렬 생성 및 디바이스 이동
    adjacency = get_adjacency_matrix(num_joints=15)
    adjacency = adjacency.to(device_obj)

    # 2-2. 모델 초기화 (in_channels=4 필수)
    gcn_model = MultiClassSTGCN(
        num_classes=4,
        num_joints=15,
        in_channels=4,  # x, y, z, visibility
        adjacency=adjacency,
        hidden_dim=128,
        dropout=0.6
    )

    # 2-3. 가중치 로드
    gcn_model.load_state_dict(torch.load(gcn_path, map_location=device_obj))
    gcn_model.to(device_obj)
    gcn_model.eval()

    print("✅ GRU 및 GCN 모델 로드 완료")

    # 3. 반환 (None 대신 실제 gcn_model 반환)
    return gru_model, gcn_model, device_obj


# --- 분석 및 LLM 관련 함수들 ---
def analyze_fall_sequence(sequence_data, gru_model, gcn_model, device):
    """
        시퀀스 데이터를 두 모델로 분석

        Args:
            sequence_data: (T, V, C) 형태의 시퀀스 데이터
            gru_model: 학습된 GRU 모델
            gcn_model: 학습된 GCN 모델
            device: torch device

        Returns:
            FallDetectionResult 객체
        """
    result = FallDetectionResult()

    # ===== 1단계: GRU 모델로 낙상 감지 =====
    gru_model.eval()

    # GRU 입력 형태: (1, T, V*C)
    T, V, C = sequence_data.shape
    gru_input = torch.FloatTensor(sequence_data.reshape(1, T, V * C)).to(device)

    with torch.no_grad():
        gru_output = gru_model(gru_input)
        gru_probs = torch.softmax(gru_output, dim=1)[0]
        gru_pred = torch.argmax(gru_output, dim=1).item()

    is_fall = (gru_pred == 1)
    fall_confidence = gru_probs[1].item()

    result.set_fall_detection(
        is_fall=is_fall,
        confidence=fall_confidence,
        probabilities=gru_probs.cpu().numpy().tolist()
    )

    # ===== 2단계: 낙상인 경우 GCN 모델로 충돌 부위 분류 =====
    if is_fall:
        gcn_model.eval()

        # GCN 입력 형태: (1, T, V, C)
        gcn_input = torch.FloatTensor(sequence_data).unsqueeze(0).to(device)

        with torch.no_grad():
            gcn_output = gcn_model(gcn_input)
            gcn_probs = torch.softmax(gcn_output, dim=1)[0]
            gcn_pred = torch.argmax(gcn_output, dim=1).item()

        impact_names = ['머리', '상지부', '엉덩이', '무릎']
        impact_location = impact_names[gcn_pred] if gcn_pred < len(impact_names) else f'부위{gcn_pred}'
        impact_confidence = gcn_probs[gcn_pred].item()

        # 모든 부위별 확률
        impact_probs = {impact_names[i]: gcn_probs[i].item()
                        for i in range(min(len(impact_names), len(gcn_probs)))}

        result.set_impact_classification(
            impact_location=impact_location,
            confidence=impact_confidence,
            probabilities=impact_probs
        )

    return result
    pass


def generate_llm_prompt_json(result):
    """
       JSON 형식의 구조화된 프롬프트 생성 (API 호출용).
       낙상이 아니면 None을 반환하여 호출을 생략합니다.
       """

    if not result.is_fall:
        # 🚨 수정: 정상인 경우 LLM 호출을 생략하기 위해 None 반환
        return None

    # 낙상인 경우 (기존 로직 유지)
    system_prompt = """당신은 응급 의료 상황을 분석하는 전문 AI입니다. 
    낙상 감지 시스템의 결과를 바탕으로 정확하고 신속한 대응 지침을 제공합니다.
    의학적 지식과 응급 처치 프로토콜을 기반으로 답변하되, 반드시 전문 의료진의 진단을 권고합니다."""

    user_prompt = f"""
    긴급 낙상 상황이 감지되었습니다.

    # ... (기존 낙상 프롬프트 내용 생략) ...

    다음 항목들을 분석해주세요:
    1. 긴급도 평가 (1-5)
    2. 예상 부상 및 심각도
    3. 즉각 대응 지침
    4. 119 신고 시 전달 내용
    5. 종합 상황 요약

    각 항목을 명확히 구분하여 한글로 작성해주세요.
    """

    return {
        "system": system_prompt,
        "user": user_prompt,
        "metadata": result.to_dict()
    }
    pass


def call_google_api(prompt_dict, api_key):
    """
        OpenAI API 호출 예시 (실제 사용 시 수정 필요)
        """
    try:
        client = OpenAI(api_key=api_key)

        response = client.chat.completions.create(
            model="gpt-4",  # 또는 "gpt-3.5-turbo"
            messages=[
                {"role": "system", "content": prompt_dict["system"]},
                {"role": "user", "content": prompt_dict["user"]}
            ],
            temperature=0.3,  # 낮은 값 = 일관된 응답
            max_tokens=1000
        )

        return response.choices[0].message.content

    except Exception as e:
        return f"API 호출 오류: {str(e)}"
    pass

def call_local_llm(prompt_dict):
    """
    로컬 LLM (Ollama) 호출 예시
    """
    try:
        import requests

        response = requests.post(
            'http://localhost:11434/api/chat',
            json={
                "model": "qwen",  # ⚠️ 실제 설치된 로컬 모델명으로 변경 (예: llama3, mistral 등)
                "messages": [
                    {"role": "system", "content": prompt_dict["system"]},
                    {"role": "user", "content": prompt_dict["user"]}
                ],
                "stream": False
            }
        )

        if response.status_code == 200:
            return response.json()['message']['content']
        else:
            return f"로컬 LLM 호출 오류: {response.status_code}"

    except Exception as e:
        return f"로컬 LLM 호출 오류: {str(e)}"


def process_and_analyze(sequence_array, gru_model, gcn_model, device):
    """
    전처리된 시퀀스 데이터를 받아 모델 추론 및 LLM 분석을 수행하는 통합 함수

    Args:
        sequence_array (np.array): (T, V, C) 형태의 Numpy 배열
        gru_model: GRU 모델 인스턴스
        gcn_model: GCN 모델 인스턴스
        device: Torch device

    Returns:
        dict: {
            'detection_result': FallDetectionResult 객체,
            'llm_analysis': str (LLM 분석 결과),
            'prompt': dict (사용된 프롬프트)
        }
    """

    # 1. 딥러닝 모델 분석 실행 (낙상 감지 + 부위 분류)
    try:
        # analyze_fall_sequence 함수는 위에서 정의되어 있어야 함
        detection_result = analyze_fall_sequence(sequence_array, gru_model, gcn_model, device)

        THRESHOLD = 0.9  # 90% 기준

        # 모델이 '낙상'이라고 했지만, 확신도가 0.9보다 낮은 경우
        if detection_result.is_fall and detection_result.fall_confidence < THRESHOLD:
            logger.warning(
                f"📉 낙상 감지됨(확신도 {detection_result.fall_confidence * 100:.1f}%)이나, "
                f"기준({THRESHOLD * 100}%) 미달로 '정상(False)' 처리합니다."
            )

            # 강제로 결과 뒤집기
            detection_result.is_fall = False

            # 낙상이 아니므로 충돌 부위 정보도 초기화
            detection_result.impact_location = None
            detection_result.impact_confidence = 0.0
            detection_result.impact_probabilities = {}

        # 로그 출력
        logger.info(f"⏱️ 발생 시각: {detection_result.timestamp}")
        logger.info(f"📊 낙상 감지: {'예' if detection_result.is_fall else '아니오'} (확신도: {detection_result.fall_confidence * 100:.1f}%)")
        if detection_result.is_fall:
            logger.info(f"💥 충돌 부위: {detection_result.impact_location} (확신도: {detection_result.impact_confidence * 100:.1f}%)")

    except Exception as e:
        logger.error(f"❌ 딥러닝 모델 분석 중 오류: {e}", exc_info=True)
        raise e

    # 2. LLM 분석을 위한 프롬프트 생성
    try:
        # generate_llm_prompt_json 함수는 위에서 정의되어 있어야 함
        prompt_dict = generate_llm_prompt_json(detection_result)
    except Exception as e:
        logger.error(f"❌ 프롬프트 생성 중 오류: {e}")
        prompt_dict = {"error": "Prompt generation failed"}

    # 3. LLM 호출 (설정에 따라 분기)
    llm_analysis = None

    # 낙상이 아닌 경우에도 LLM을 호출할지, 스킵할지 결정 (비용 절감을 위해 스킵 가능)
    # 여기서는 낙상일 때만 호출하거나, 항상 호출하도록 설정 가능합니다.
    # 예시: 낙상일 때만 호출하려면 -> if detection_result.is_fall:

    try:
        if config.LLM_TYPE == 'google':
            if not config.API_KEY:
                llm_analysis = "⚠️ Google API 키가 설정되지 않았습니다."
            else:
                logger.info("🤖 Google Gemini 분석 요청 중...")
                llm_analysis = call_google_api(prompt_dict, config.API_KEY)

        elif config.LLM_TYPE == 'local':
            logger.info("🤖 Local LLM 분석 요청 중...")
            llm_analysis = call_local_llm(prompt_dict)

        elif config.LLM_TYPE == 'openai':
            # OpenAI 호출 함수가 있다면 연결
            llm_analysis = "OpenAI 기능은 아직 구현되지 않았습니다."

        else:
            llm_analysis = f"지원하지 않는 LLM 타입입니다: {config.LLM_TYPE}"

    except Exception as e:
        logger.error(f"❌ LLM 호출 중 오류: {e}", exc_info=True)
        llm_analysis = "LLM 분석을 수행할 수 없습니다."

    # 4. 최종 결과 반환
    logger.info("✅ 분석 완료")

    return {
        'detection_result': detection_result,
        'llm_analysis': llm_analysis,
        'prompt': prompt_dict
    }
    pass