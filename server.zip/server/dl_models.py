# dl_models.py
import torch
import torch.nn as nn
import torch.nn.functional as F


class GRUFallDetection(nn.Module):
    def __init__(self, input_dim, hidden_dim=128, num_layers=2,
                 num_classes=2, dropout=0.5, bidirectional=True):
        super(GRUFallDetection, self).__init__()
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.bidirectional = bidirectional
        self.num_directions = 2 if bidirectional else 1

        self.gru = nn.GRU(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0,
            bidirectional=bidirectional
        )
        self.layer_norm = nn.LayerNorm(hidden_dim * self.num_directions)
        self.attention = nn.Linear(hidden_dim * self.num_directions, 1)
        self.fc1 = nn.Linear(hidden_dim * self.num_directions, hidden_dim)
        self.dropout = nn.Dropout(dropout)
        self.fc2 = nn.Linear(hidden_dim, num_classes)

    def attention_net(self, gru_output):
        attention_weights = torch.softmax(self.attention(gru_output), dim=1)
        weighted = attention_weights * gru_output
        context = torch.sum(weighted, dim=1)
        return context, attention_weights

    def forward(self, x):
        # batch_size = x.size(0) # unused
        gru_output, _ = self.gru(x)
        context, _ = self.attention_net(gru_output)
        context = self.layer_norm(context)
        out = F.relu(self.fc1(context))
        out = self.dropout(out)
        out = self.fc2(out)
        return out


class GraphConvolution(nn.Module):
    def __init__(self, in_features, out_features, adjacency):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.adjacency = adjacency
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        self.bias = nn.Parameter(torch.FloatTensor(out_features))
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.weight)
        nn.init.zeros_(self.bias)

    def forward(self, x):
        batch_size, time_steps, num_joints, _ = x.shape
        output = []
        for t in range(time_steps):
            xt = x[:, t, :, :]
            support = torch.matmul(xt, self.weight)
            output_t = torch.einsum('jk,bkf->bjf', self.adjacency, support)
            output_t = output_t + self.bias
            output.append(output_t.unsqueeze(1))
        return torch.cat(output, dim=1)


class MultiClassSTGCN(nn.Module):
    def __init__(self, num_classes, num_joints, in_channels, adjacency,
                 hidden_dim=64, dropout=0.6):
        super(MultiClassSTGCN, self).__init__()
        self.register_buffer('adjacency', adjacency)

        # 모델 구조 (기존 코드와 동일하게 유지)
        self.gcn1 = GraphConvolution(in_channels, hidden_dim, adjacency)
        self.gcn2 = GraphConvolution(hidden_dim, hidden_dim, adjacency)
        self.gcn3 = GraphConvolution(hidden_dim, hidden_dim, adjacency)
        self.gcn4 = GraphConvolution(hidden_dim, hidden_dim, adjacency)

        self.tcn1 = nn.Conv2d(hidden_dim, hidden_dim, kernel_size=(5, 1), padding=(2, 0))
        self.tcn2 = nn.Conv2d(hidden_dim, hidden_dim, kernel_size=(5, 1), padding=(2, 0))
        self.tcn3 = nn.Conv2d(hidden_dim, hidden_dim, kernel_size=(5, 1), padding=(2, 0))

        self.bn1 = nn.BatchNorm2d(hidden_dim)
        self.bn2 = nn.BatchNorm2d(hidden_dim)
        self.bn3 = nn.BatchNorm2d(hidden_dim)
        self.bn4 = nn.BatchNorm2d(hidden_dim)

        self.dropout = nn.Dropout(dropout)
        self.fc1 = nn.Linear(hidden_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, num_classes)

    def forward(self, x):
        x = self.gcn1(x)
        x = x.permute(0, 3, 1, 2)
        x = self.bn1(x);
        x = F.relu(x)
        x = self.tcn1(x);
        x = x.permute(0, 2, 3, 1)

        x = self.gcn2(x)
        x = x.permute(0, 3, 1, 2)
        x = self.bn2(x);
        x = F.relu(x)
        x = self.tcn2(x);
        x = x.permute(0, 2, 3, 1)

        x = self.gcn3(x)
        x = x.permute(0, 3, 1, 2)
        x = self.bn3(x);
        x = F.relu(x)
        x = self.tcn3(x);
        x = x.permute(0, 2, 3, 1)

        x = self.gcn4(x)
        x = x.permute(0, 3, 1, 2)
        x = self.bn4(x);
        x = F.relu(x)

        x = F.adaptive_avg_pool2d(x, (1, 1))
        x = x.view(x.size(0), -1)
        x = self.dropout(x)
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = self.fc2(x)
        return x