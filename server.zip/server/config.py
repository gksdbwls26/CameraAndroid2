# config.py
import os

# 경로 설정
GRU_PATH = 'best_gru_model.pth'
GCN_PATH = 'best_impact_model.pth'

# API 설정
LLM_TYPE = 'google'  # 'openai', 'claude', 'google', 'local'
API_KEY = 'AIzaSyAkuyGZyl1ky8Hef0pUZCkYV6IDmdmMcwo  2'  # 실제 환경에서는 환경변수 사용 권장

# 전처리 상수
EMA_ALPHA = 0.2
SMOOTHING_THRESHOLD = 0.5