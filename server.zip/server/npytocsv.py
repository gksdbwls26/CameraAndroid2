import numpy as np
import pandas as pd
import os
import glob

# =======================================================
# 1. 설정 (main.py의 설정과 동일해야 함)
# =======================================================
# ⚠️ 모델이 사용하는 관절 수 및 채널 수에 맞게 설정하세요.
NUM_JOINTS = 15
CHANNELS = ['x', 'y', 'z', 'v']

# NPY 파일이 저장된 디렉토리 (main.py의 DEBUG_DIR과 동일)
NPY_INPUT_DIR = "debug_sequences"
# CSV 파일을 저장할 새로운 디렉토리
CSV_OUTPUT_DIR = "debug_csv_sequences_batch"


# =======================================================
# 2. 변환 함수
# =======================================================

def convert_npy_to_csv(npy_file_path: str, output_dir: str):
    """
    (T, V, C) 형태의 NPY 파일을 CSV로 변환하여 저장합니다.
    """
    try:
        # 1. NPY 파일 로드
        sequence_array = np.load(npy_file_path)

        # 2. 배열 형태 확인 및 상수 설정
        if len(sequence_array.shape) != 3:
            print(f"⚠️ 경고: {npy_file_path} 파일이 3D 형태(T, V, C)가 아닙니다. 스킵합니다.")
            return

        T, V, C = sequence_array.shape

        if V != NUM_JOINTS or C != len(CHANNELS):
            print(
                f"⚠️ 경고: {npy_file_path} 형태 ({T}, {V}, {C})가 예상 형태 ({NUM_JOINTS}, {len(CHANNELS)})와 일치하지 않습니다. 스킵합니다.")
            return

        # 3. 컬럼 이름 정의
        joint_prefix = [f'joint_{i:02d}' for i in range(NUM_JOINTS)]
        col_names = [f'{j}_{c}' for j in joint_prefix for c in CHANNELS]

        # 4. (T, V, C) 배열을 (T, V*C) 2D로 평탄화
        flat_sequence = sequence_array.reshape(T, V * C)

        # 5. Pandas DataFrame 생성 및 CSV 저장
        df_sequence = pd.DataFrame(flat_sequence, columns=col_names)

        # 파일 이름 설정
        filename_base = os.path.basename(npy_file_path).replace('.npy', '')
        csv_output_path = os.path.join(output_dir, f"{filename_base}.csv")

        # CSV 파일로 저장
        df_sequence.to_csv(csv_output_path, index=False)
        print(f"  ✅ 변환 완료: {csv_output_path}")

    except Exception as e:
        print(f"❌ 오류 발생 중 {npy_file_path} 변환: {e}")


# =======================================================
# 3. 메인 실행 블록
# =======================================================

if __name__ == "__main__":
    if not os.path.exists(NPY_INPUT_DIR):
        print(f"❌ 오류: 입력 디렉토리 '{NPY_INPUT_DIR}'를 찾을 수 없습니다.")
        print("FastAPI 서버가 NPY 파일을 저장하도록 먼저 실행해 주세요.")
    else:
        os.makedirs(CSV_OUTPUT_DIR, exist_ok=True)

        npy_files = glob.glob(os.path.join(NPY_INPUT_DIR, "*.npy"))

        if not npy_files:
            print(f"⚠️ '{NPY_INPUT_DIR}' 폴더에 변환할 NPY 파일이 없습니다.")
        else:
            print(f"총 {len(npy_files)}개의 NPY 파일을 CSV로 변환합니다.")
            for npy_file in npy_files:
                convert_npy_to_csv(npy_file, CSV_OUTPUT_DIR)
            print("\n✅ 모든 변환 작업 완료.")